interface I1
{
    void show();
}
class testI1
{
  public static void main(String s[])
   {
     I1 obj = new I1(){
		public void show()
			{
			  System.out.println("hello how are you");
			}		 
	 };
	 obj.show();
	 I1 obj2 = new I1(){
		public void show()
			{
			  System.out.println("hello how are you");
			}		 
	 };
	 obj2.show();
   }
}