import java.util.*;
import java.util.stream.Collectors;
class Student{
 int rollno;
 String name;
 int marks;
 Student(int rollno,String name,int marks)
 {
   this.rollno=rollno;
   this.name=name;
   this.marks=marks;
 }
}
class DSLStreamPrint
{
  public static void main(String s[])
  {
    List<Student> studentlist = new ArrayList<Student>();
	studentlist.add(new Student(123,"sunil kumar",45));
	studentlist.add(new Student(124,"Amit kumar",55));
	studentlist.add(new Student(125,"Ajay kumar",65));
	studentlist.add(new Student(126,"vijay kumar",75));
	studentlist.add(new Student(127,"anil kumar",85));
	
	 studentlist.stream().filter(st->st.marks>60).forEach(st->System.out.println(st.name+st.marks)) ;
	 
  }
}

// studentlist.stream().map();
//studentlist.stream.collect(Collectors.toList());
 