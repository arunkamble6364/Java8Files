import java.util.*;
import java.util.stream.Collectors;
class StringManup
{
  public static void main(String s[])
  {
    List<String> names=new ArrayList<String>();
	  names.add(new String("sunil"));
	  names.add(new String("Anil"));
	  names.add(new String("ajay"));
	  names.add(new String("vijay"));
	  
	  List<String> namesUC= names.stream().map(String::toUpperCase).collect(Collectors.toList());
	  
	  System.out.println(namesUC);
	  
	  names.stream().map(n->n.length()).forEach(System.out::println);
  }
}