import java.util.*;
class Item{
  int id;
  String iname;
  float price;
  Item(int id,String in,float p)
  {
    this.id=id;
	iname=in;
	price=p;
  }
}

class ItemPriceSum
{
	public static void main(String s[])
	{
		List<Item> itemlist= new ArrayList<Item>();
		
		itemlist.add(new Item(101,"Tv",25000));
		itemlist.add(new Item(102,"Microwave oven",5000));
		itemlist.add(new Item(103,"washingmachine",20000));
		itemlist.add(new Item(104,"Laptop",75000));
		itemlist.add(new Item(105,"samsung mobile",15000));
		itemlist.add(new Item(106,"Sofa set",20000));
		
		Float totalprice=itemlist.stream().map(item->item.price).reduce(0.0f,(sum,price)->sum+price);
		
		System.out.println(totalprice);
		
	}
}
// when we perform any airthmatic operation all byte, short is converted to integer first, if in operation we have long then it is converted to long same thing is happen with float it will be converted to double first before operation 
//byte b=1;
//for(b=1;b<=123;b++)
	  SOP(b);