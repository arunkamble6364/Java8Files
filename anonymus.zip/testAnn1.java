abstract class ann1
{
  abstract void show();
}
class testAnn1
{
  public static void main(String s[])
   {
     ann1 obj = new ann1(){
		 void show()
			{
			  System.out.println("hello how are you");
			}		 
	 };
	 obj.show();
	 ann1 obj2 = new ann1(){
		 void show()
			{
			  System.out.println("hello how are you");
			}		 
	 };
	 obj2.show();
   }
}