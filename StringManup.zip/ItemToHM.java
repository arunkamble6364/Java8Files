import java.util.*;
import java.util.stream.Collectors;
class Item{
  int id;
  String iname;
  float price;
  Item(int id,String in,float p)
  {
    this.id=id;
	iname=in;
	price=p;
  }
}

class ItemToHM
{
	public static void main(String s[])
	{
		List<Item> itemlist= new ArrayList<Item>();
		
		itemlist.add(new Item(101,"Tv",25000));
		itemlist.add(new Item(102,"Microwave oven",5000));
		itemlist.add(new Item(103,"washingmachine",20000));
		itemlist.add(new Item(104,"Laptop",75000));
		itemlist.add(new Item(105,"samsung mobile",15000));
		itemlist.add(new Item(106,"Sofa set",20000));
		
		Map<Integer,String> itemmap =itemlist.stream().collect(Collectors.toMap(i->i.id,i->i.iname) );
		
		System.out.println(itemmap);
		/* you have learnt we need to stream our list or arraylist to our stream api, in stream we must conver the data to stream so that we have applied here stream function. now after applying stream function it returns a stream that stream can be converted to any other data structure. toMap(key,value) we here i.id as key and i.iname as value*/
	}
}