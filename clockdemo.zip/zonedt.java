import java.time.*;
class zonedt
{
 public static void main(String s[])
  {
    LocalDateTime dtobj= LocalDateTime.of(2022,1,10,14,23);
	ZoneId india= ZoneId.of("Asia/Kolkata");
	ZonedDateTime zdt = ZonedDateTime.of(dtobj,india);
	System.out.println("time as per india zone"+ zdt);
	
	ZoneId usa= ZoneId.of("America/Chicago");
	ZonedDateTime usaDT = ZonedDateTime.of(dtobj,usa);
	System.out.println("time as per usa zone"+ usaDT);
  }
}
