class ThreadDemo1
{
  public static void main(String s[])
  {
    Runnable r1= ()->{
		 int i=1;
		 while(i!=0)
		 {
	     System.out.print (i++ +" " );
		 }
	 };
	 Thread t1= new Thread(r1);
	 t1.start();
  }
}