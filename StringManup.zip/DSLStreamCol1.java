import java.util.*;
import java.util.stream.Collectors;
class Student{
 int rollno;
 String name;
 int marks;
 Student(int rollno,String name,int marks)
 {
   this.rollno=rollno;
   this.name=name;
   this.marks=marks;
 }
}
class DSLStreamCol1
{
  public static void main(String s[])
  {
    List<Student> studentlist = new ArrayList<Student>();
	studentlist.add(new Student(123,"sunil kumar",45));
	studentlist.add(new Student(124,"Amit kumar",55));
	studentlist.add(new Student(125,"Ajay kumar",65));
	studentlist.add(new Student(126,"vijay kumar",75));
	studentlist.add(new Student(127,"anil kumar",85));
	
	List<Integer> marksList= studentlist.stream().filter(st->st.marks>60).map(st->st.marks).collect(Collectors.toList() );
	//.collect(Collectors.toMap() to.Set()
	 //with filter we filter the result as per condition
	 // with map we are fetching the values
	 // with collects we store the values to new list 
	 //st is fetched from studentlist as object 
	System.out.println(marksList);
  }
}
// why we use filter of stream instead of if else and for loop 
// if we are having more than 5000 records is it good to iterate it no it not a good 