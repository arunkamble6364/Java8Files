import java.util.*;
class LambdaForEach
{
  public static void main(String s[])
  {
    List<String> names=new ArrayList<String>();
	names.add("umesh");
	names.add("anil");
	names.add("sunil");
	names.add("Ajay");
	names.add("vijay");
	names.forEach((v)-> System.out.println(v));
  }
}