interface L2
{
  void show(String name);
}
class demoL2
{
 public static void main(String s[])
 {
  L2 obj =(name)->{
    System.out.println("name "+name);
  };
  obj.show("sunil kumar");
 }
}