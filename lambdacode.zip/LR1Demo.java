interface LR1
{
  int sum(int a , int b);
}
class LR1Demo 
{
  public static void main(String s[])
  {
    LR1 obj= (a,b)->{
	    return (a+b);
	  };
	  int t= obj.sum(10,2);
	  System.out.println(t);
	LR1 obj2= (a,b)->(a+b);	
	System.out.println(obj2.sum(20,3));
  }
}