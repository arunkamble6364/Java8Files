import java.util.*;
class Student{
 int rollno;
 String name;
 int marks;
 Student(int rollno,String name,int marks)
 {
   this.rollno=rollno;
   this.name=name;
   this.marks=marks;
 }
}
class DSL
{
  public static void main(String s[])
  {
    List<Student> studentlist = new ArrayList<Student>();
	studentlist.add(new Student(123,"sunil kumar",45));
	studentlist.add(new Student(124,"Amit kumar",55));
	studentlist.add(new Student(125,"Ajay kumar",65));
	studentlist.add(new Student(126,"vijay kumar",75));
	studentlist.add(new Student(127,"anil kumar",85));
	
	List<Integer> marksList= new ArrayList<Integer>();
	for(Student objS:studentlist)
	{
		if(objS.marks>60)
		{
			marksList.add(objS.marks);
		}
		
	}// end of for loop
	System.out.println(marksList);
  }
}