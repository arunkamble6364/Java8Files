/*getZone() means it will give us current time zone

instant()
systemDefaultZone() */
import java.time.Clock;

class clockdemo
{
  public static void main(String s[])
   {
     Clock c = Clock.systemDefaultZone();
	 System.out.println(c.getZone());
	 Clock obj = Clock.systemUTC();
	 System.out.println(c.getZone());
	 System.out.println(obj.instant());
	 
   }
}
