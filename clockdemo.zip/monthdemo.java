import java.time.*;
class monthdemo
{
 public static void main(String s[])
 {
   MonthDay md = MonthDay.now();
   LocalDate date = md.atYear(2000);
   System.out.println(date);
   System.out.println(md);   
 }
}