interface l1{
  void show();
}
class demol1
{
  public static void main(String s[])
  {
    l1 obj = ()->{
	  System.out.println("Test of lamda expression");
	};
	obj.show();
	
	 l1 obj2 = ()->{
	   for(int i=1;i<10;i++) 
		     System.out.print(" " + i);
	};
	obj2.show();
	
	l1 obj3 = ()->{
	  System.out.println("3rd object using lambda expression");
	};
	obj3.show();
  }
}