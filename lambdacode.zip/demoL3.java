interface L3
{
  void max(int a, int b);
}
class demoL3
{
 public static void main(String s[])
 {
  L3 obj =(a,b)->{
     if(a>b)
	   System.out.println("Max"+a);
	 else
		System.out.println("Max"+b);
  };
  obj.max(10,3);
 }
}