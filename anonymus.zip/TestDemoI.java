interface DemoI
{
  default void show()
 {
  System.out.println("This is show method");
 }
}
class TestDemoI implements DemoI
{
  void test()
  {
    System.out.println("Test method of class");
  }
  public void show()
  {
	  System.out.println("Method is overridden");
	  
  }
  public static void main(String s[])
   {
    TestDemoI obj =new TestDemoI();
	obj.show();
	obj.test();	
   }
}