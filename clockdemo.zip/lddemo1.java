import java.time.LocalDate;
import java.time.LocalDateTime;
public class lddemo1
{
  public static void main(String s[])
  {
   LocalDate objdate= LocalDate.now();
     /*System.out.println(objdate);
	 LocalDate olddate = objdate.minusDays(30);
	 LocalDate nextdate = objdate.plusDays(30);
	 System.out.println(olddate);
	 System.out.println(nextdate);*/
	 LocalDate hbd=LocalDate.of(2022,1,22);
	 System.out.println(hbd);
	 LocalDateTime hbdtime = hbd.atTime(3,23,33);
	 System.out.println(hbdtime);
  }
}