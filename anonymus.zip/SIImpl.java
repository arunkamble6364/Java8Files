interface SI
{
  static void show()
  {
   System.out.println("static method demo");
  }
  void absm1();
  default void m2()
  {
    System.out.println("M2 is default method");
  }
}
class SIImpl implements SI
{
  public void absm1()
  {	  
	 System.out.println("ABsm1 is override");  
  }
  public static void main(String s[])
  {
	  SIImpl obj = new SIImpl();
	  obj.m2();
	  obj.absm1();
	  SIImpl.show();	  // i am getting error 
  }
}